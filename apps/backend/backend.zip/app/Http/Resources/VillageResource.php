<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VillageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'code' => $this->code,
            'head_name' => $this->head_name,
            'address' => $this->address,
            'phone' => $this->phone,
            'history' => $this->history,
            'vision' => $this->vision,
            'mission' => $this->mission,
        ];
    }
}
